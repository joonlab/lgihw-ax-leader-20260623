# Gemini API 레퍼런스 (브라우저 단일 HTML용)

> **이 문서의 용도 (스킬로 사용하기)**
> 이 레퍼런스를 AI 코딩 에이전트(Antigravity 등)에 **컨텍스트/규칙(스킬)으로 첨부**하면,
> 에이전트가 "Gemini API로 ○○하는 웹앱 만들어줘"라는 한 줄 요청만으로
> **동작하는 단일 HTML AI 웹앱을 알아서 만들 수 있습니다.**
> 아래 규칙·패턴을 그대로 따르도록 지시하세요.

---

## 0. 에이전트 작업 규칙 (READ FIRST)

AI 웹앱을 만들 때 **반드시** 다음을 지킨다.

1. **결과물은 외부 의존성이 없는 단일 `.html` 파일**로 만든다. (HTML + CSS + JS 한 파일, 빌드 도구·npm·CDN 불필요)
2. **모델 ID는 `gemini-3.5-flash`** 를 기본으로 쓴다. (더 가볍게: `gemini-3.1-flash-lite`)
3. API 키는 **사용자가 화면에서 입력**하게 한다. 코드에 하드코딩하지 않는다.
4. 호출은 브라우저 `fetch`로 **직접** 한다. (Gemini API는 CORS 허용 → 별도 서버 불필요)
5. **에러 처리 3종**(키 미입력 / HTTP 실패 / 응답 파싱 실패)을 항상 포함한다.
6. 구조화된 출력이 필요하면 **`responseMimeType: "application/json"` + 프롬프트에 JSON 스키마 명시**를 함께 쓴다.
7. 응답 텍스트는 항상 **`data.candidates[0].content.parts[0].text`** 에서 꺼낸다.

---

## 1. 엔드포인트 / 인증

| 항목 | 값 |
|------|----|
| 메서드 | `POST` |
| URL | `https://generativelanguage.googleapis.com/v1beta/models/{MODEL_ID}:generateContent` |
| 예시 URL | `.../models/gemini-3.5-flash:generateContent` |
| 인증 헤더 | `x-goog-api-key: <API_KEY>` |
| 콘텐츠 헤더 | `Content-Type: application/json` |
| 키 발급 | https://aistudio.google.com/apikey (무료, 결제 불필요) |

> ⚠️ 키는 URL 쿼리스트링(`?key=`)이 아니라 **헤더 `x-goog-api-key`** 로 보내는 것이 현재 권장 방식.

---

## 2. 사용 가능한 모델 (2026-06 기준)

| 모델 ID | 특징 | 권장 용도 |
|---|---|---|
| **`gemini-3.5-flash`** | 균형형, 모든 공식 quickstart 기본 | ⭐ 텍스트 정리/요약/분류/추출 (기본 선택) |
| `gemini-3.1-flash-lite` | 가장 빠르고 무료 한도 넉넉 | 단순·대량 작업 |
| `gemini-2.5-flash` | 구버전(사용 가능) | 백업 |

---

## 3. 요청 Body 구조

### 3-1. 최소 형태

```json
{
  "contents": [
    { "parts": [ { "text": "여기에 프롬프트" } ] }
  ]
}
```

### 3-2. 옵션 포함 (실전 권장)

```json
{
  "contents": [
    { "parts": [ { "text": "여기에 프롬프트" } ] }
  ],
  "generationConfig": {
    "temperature": 0.2,
    "responseMimeType": "application/json"
  }
}
```

| 필드 | 설명 |
|------|------|
| `contents[].parts[].text` | 모델에 보낼 프롬프트 텍스트 |
| `generationConfig.temperature` | 0~1. 정리/추출처럼 일관성이 중요하면 **0.2 권장** |
| `generationConfig.responseMimeType` | `"application/json"` 설정 시 모델이 **JSON만** 반환 → 파싱 안정 |
| `generationConfig.maxOutputTokens` | (선택) 출력 길이 상한 |
| `systemInstruction` | (선택) `{ "parts": [{ "text": "시스템 지시" }] }` 형태로 역할 고정 가능 |

---

## 4. 응답 구조

```json
{
  "candidates": [
    {
      "content": { "parts": [ { "text": "여기에 생성 결과" } ], "role": "model" },
      "finishReason": "STOP"
    }
  ],
  "promptFeedback": { "blockReason": "..." }   // (차단 시에만)
}
```

- **생성 결과 텍스트 위치 → `data.candidates[0].content.parts[0].text`**
- `candidates`가 비어있으면 → `promptFeedback.blockReason` 확인 (안전 필터 차단)
- `finishReason`이 `STOP`이 아니면(`MAX_TOKENS`, `SAFETY` 등) 응답이 잘렸을 수 있음

---

## 5. fetch 호출 표준 패턴 (복붙용)

```javascript
const MODEL = "gemini-3.5-flash";
const ENDPOINT =
  `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

async function callGemini(apiKey, prompt, { json = false } = {}) {
  const body = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.2,
      ...(json ? { responseMimeType: "application/json" } : {})
    }
  };

  const res = await fetch(ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey
    },
    body: JSON.stringify(body)
  });

  // HTTP 에러 처리
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json())?.error?.message || ""; } catch {}
    if (res.status === 403) throw new Error("API 키가 잘못되었거나 권한이 없습니다.");
    if (res.status === 429) throw new Error("무료 사용 한도 초과. 잠시 후 다시 시도하세요.");
    if (res.status >= 500) throw new Error("Gemini 서버 일시 오류. 잠시 후 재시도.");
    throw new Error(`요청 실패 (HTTP ${res.status}). ${detail}`);
  }

  const data = await res.json();

  // 안전 차단 / 빈 응답 방어
  const cand = data?.candidates?.[0];
  if (!cand) {
    const reason = data?.promptFeedback?.blockReason;
    throw new Error(reason ? `응답 차단됨 (${reason})` : "응답 후보가 없습니다.");
  }
  const text = cand?.content?.parts?.[0]?.text;
  if (!text) throw new Error("응답에서 텍스트를 찾지 못했습니다.");

  return text;
}
```

---

## 6. 구조화 출력(JSON) 받기 — 표/카드 UI를 만들 때

모델 응답을 표·목록으로 렌더링하려면 **JSON으로 받는 것**이 가장 안정적이다.

### 6-1. 프롬프트에 스키마를 명시한다

```text
반드시 아래 JSON 형식 "하나만" 출력하세요. 코드블록(```)이나 설명을 덧붙이지 마세요.
{
  "summary": "요약 문장",
  "items": [ { "task": "할 일", "owner": "담당자", "due": "기한" } ]
}
```

### 6-2. `responseMimeType: "application/json"` 을 함께 켠다 (위 3-2 참고)

### 6-3. 응답 JSON을 방어적으로 파싱한다

모델이 가끔 ```` ```json ```` 코드펜스나 앞뒤 잡설을 붙일 수 있으므로 정리 후 파싱한다.

```javascript
function parseModelJson(text) {
  let s = text.trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
  const first = s.indexOf("{"), last = s.lastIndexOf("}");
  if (first !== -1 && last > first) s = s.slice(first, last + 1);
  return JSON.parse(s);
}
```

---

## 7. 프롬프트 설계 패턴 (한국어 업무 자동화)

좋은 프롬프트의 4요소 — **역할 + 작업 + 규칙 + 출력형식**.

```text
[역할] 당신은 한국 기업의 회의록을 분석하는 전문 비서입니다.
[작업] 아래 회의록에서 요약과 액션 아이템을 정리하세요.
[규칙]
 - 회의록에 없는 내용을 지어내지 마세요.
 - 담당/기한이 명시되지 않았으면 "미정"으로 표기하세요.
[출력형식] 아래 JSON 형식 하나만 출력하세요: { ... }
[입력] {{회의록 텍스트}}
```

**핵심 원칙**
- "지어내지 마라(환각 금지)" 규칙을 명시한다.
- 누락 값 처리 규칙("없으면 미정")을 준다 → 빈 셀 방지.
- 출력 형식을 **예시 JSON으로** 보여준다 → 파싱 성공률 상승.
- `temperature`는 0.2 내외로 낮춘다 → 매번 일관된 결과.

---

## 8. 응용 아이디어 (같은 패턴으로 만들 수 있는 웹앱)

이 레퍼런스의 **호출 패턴(5번) + 프롬프트 설계(7번)** 만 바꾸면 다음을 그대로 만들 수 있다.

| 웹앱 | 입력 | JSON 출력 스키마(예) |
|------|------|----------------------|
| 회의록 → 액션아이템 | 회의록 | `{ summary, items:[{task,owner,due}] }` |
| 이메일 정중하게 다듬기 | 초안 | `{ subject, body }` |
| 고객 문의 분류기 | 문의 내용 | `{ category, urgency, suggestedReply }` |
| 보고서 핵심 3줄 요약 | 긴 글 | `{ bullets:[ "...", "...", "..." ] }` |
| 회의 일정 추출 | 대화 로그 | `{ events:[{title,date,attendees}] }` |
| 영문 → 한국어 비즈니스 번역 | 영문 | `{ translated, glossary:[{en,ko}] }` |

> 에이전트 지시 예시:
> *"첨부한 `Gemini-API_레퍼런스.md`의 패턴을 따라, **고객 문의 분류기** 단일 HTML 웹앱을 만들어줘.
> API 키 입력란 + 문의 입력 textarea + 분류 버튼 + 결과(카테고리/긴급도/추천답변) 표시. JSON 스키마는 위 표대로."*

---

## 9. 자주 만나는 에러와 해결

| 증상 | 원인 | 해결 |
|------|------|------|
| `403 / API key not valid` | 키 오타·공백·권한 | 키 재복사, 새 키 발급 |
| `429 Too Many Requests` | 무료 한도 초과 | 1~2분 후 재시도 |
| `400 Bad Request` | body 형식 오류 | `contents[].parts[].text` 구조 확인 |
| 응답이 비어있음 | 안전 필터 차단 | `promptFeedback.blockReason` 확인, 입력 점검 |
| `JSON.parse` 실패 | 모델이 코드펜스/잡설 추가 | 6-3 방어적 파서 사용 + `responseMimeType` 켜기 |
| `Failed to fetch` | 네트워크/CORS | 인터넷 확인 (Gemini는 CORS 허용이라 보통 네트워크 문제) |

---

## 10. 빠른 점검용 cURL (터미널 테스트)

```bash
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -H 'Content-Type: application/json' \
  -X POST \
  -d '{ "contents": [ { "parts": [ { "text": "한 문장으로 자기소개해줘" } ] } ] }'
```

---

### 참고 출처
- 모델 목록: https://ai.google.dev/gemini-api/docs/models
- 빠른 시작: https://ai.google.dev/gemini-api/docs/quickstart
- 요금/무료티어: https://ai.google.dev/gemini-api/docs/pricing
- API 키: https://ai.google.dev/gemini-api/docs/api-key
